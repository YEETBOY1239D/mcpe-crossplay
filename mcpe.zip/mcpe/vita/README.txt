Just get the vita mcpe port from this:

https://github.com/minecraftpe-vita/minecraftpe-vita/releases

also no 3ds support
