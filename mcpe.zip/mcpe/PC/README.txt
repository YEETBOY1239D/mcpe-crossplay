fyi this pc port runs on 32 bit (or else it wouldnt work with ios and vita)
