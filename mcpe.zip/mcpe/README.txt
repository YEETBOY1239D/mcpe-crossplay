for the ios version, just get it from veteris or some other place, idk. Giving you the ipa would be too risky and you can just sideload the official ipa and it will work perfectly fine.
